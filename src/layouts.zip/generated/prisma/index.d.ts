
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model WordList
 * 
 */
export type WordList = $Result.DefaultSelection<Prisma.$WordListPayload>
/**
 * Model WordPair
 * 
 */
export type WordPair = $Result.DefaultSelection<Prisma.$WordPairPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more WordLists
 * const wordLists = await prisma.wordList.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more WordLists
   * const wordLists = await prisma.wordList.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.wordList`: Exposes CRUD operations for the **WordList** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more WordLists
    * const wordLists = await prisma.wordList.findMany()
    * ```
    */
  get wordList(): Prisma.WordListDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.wordPair`: Exposes CRUD operations for the **WordPair** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more WordPairs
    * const wordPairs = await prisma.wordPair.findMany()
    * ```
    */
  get wordPair(): Prisma.WordPairDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.9.0
   * Query Engine version: 81e4af48011447c3cc503a190e86995b66d2a28e
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    WordList: 'WordList',
    WordPair: 'WordPair'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "wordList" | "wordPair"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      WordList: {
        payload: Prisma.$WordListPayload<ExtArgs>
        fields: Prisma.WordListFieldRefs
        operations: {
          findUnique: {
            args: Prisma.WordListFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.WordListFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload>
          }
          findFirst: {
            args: Prisma.WordListFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.WordListFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload>
          }
          findMany: {
            args: Prisma.WordListFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload>[]
          }
          create: {
            args: Prisma.WordListCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload>
          }
          createMany: {
            args: Prisma.WordListCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.WordListCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload>[]
          }
          delete: {
            args: Prisma.WordListDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload>
          }
          update: {
            args: Prisma.WordListUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload>
          }
          deleteMany: {
            args: Prisma.WordListDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.WordListUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.WordListUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload>[]
          }
          upsert: {
            args: Prisma.WordListUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordListPayload>
          }
          aggregate: {
            args: Prisma.WordListAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateWordList>
          }
          groupBy: {
            args: Prisma.WordListGroupByArgs<ExtArgs>
            result: $Utils.Optional<WordListGroupByOutputType>[]
          }
          count: {
            args: Prisma.WordListCountArgs<ExtArgs>
            result: $Utils.Optional<WordListCountAggregateOutputType> | number
          }
        }
      }
      WordPair: {
        payload: Prisma.$WordPairPayload<ExtArgs>
        fields: Prisma.WordPairFieldRefs
        operations: {
          findUnique: {
            args: Prisma.WordPairFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.WordPairFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload>
          }
          findFirst: {
            args: Prisma.WordPairFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.WordPairFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload>
          }
          findMany: {
            args: Prisma.WordPairFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload>[]
          }
          create: {
            args: Prisma.WordPairCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload>
          }
          createMany: {
            args: Prisma.WordPairCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.WordPairCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload>[]
          }
          delete: {
            args: Prisma.WordPairDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload>
          }
          update: {
            args: Prisma.WordPairUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload>
          }
          deleteMany: {
            args: Prisma.WordPairDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.WordPairUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.WordPairUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload>[]
          }
          upsert: {
            args: Prisma.WordPairUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WordPairPayload>
          }
          aggregate: {
            args: Prisma.WordPairAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateWordPair>
          }
          groupBy: {
            args: Prisma.WordPairGroupByArgs<ExtArgs>
            result: $Utils.Optional<WordPairGroupByOutputType>[]
          }
          count: {
            args: Prisma.WordPairCountArgs<ExtArgs>
            result: $Utils.Optional<WordPairCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    wordList?: WordListOmit
    wordPair?: WordPairOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type WordListCountOutputType
   */

  export type WordListCountOutputType = {
    words: number
  }

  export type WordListCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    words?: boolean | WordListCountOutputTypeCountWordsArgs
  }

  // Custom InputTypes
  /**
   * WordListCountOutputType without action
   */
  export type WordListCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordListCountOutputType
     */
    select?: WordListCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * WordListCountOutputType without action
   */
  export type WordListCountOutputTypeCountWordsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WordPairWhereInput
  }


  /**
   * Models
   */

  /**
   * Model WordList
   */

  export type AggregateWordList = {
    _count: WordListCountAggregateOutputType | null
    _avg: WordListAvgAggregateOutputType | null
    _sum: WordListSumAggregateOutputType | null
    _min: WordListMinAggregateOutputType | null
    _max: WordListMaxAggregateOutputType | null
  }

  export type WordListAvgAggregateOutputType = {
    updateTime: number | null
    createTime: number | null
  }

  export type WordListSumAggregateOutputType = {
    updateTime: bigint | null
    createTime: bigint | null
  }

  export type WordListMinAggregateOutputType = {
    id: string | null
    name: string | null
    author: string | null
    description: string | null
    updateTime: bigint | null
    createTime: bigint | null
  }

  export type WordListMaxAggregateOutputType = {
    id: string | null
    name: string | null
    author: string | null
    description: string | null
    updateTime: bigint | null
    createTime: bigint | null
  }

  export type WordListCountAggregateOutputType = {
    id: number
    name: number
    author: number
    description: number
    updateTime: number
    createTime: number
    settings: number
    _all: number
  }


  export type WordListAvgAggregateInputType = {
    updateTime?: true
    createTime?: true
  }

  export type WordListSumAggregateInputType = {
    updateTime?: true
    createTime?: true
  }

  export type WordListMinAggregateInputType = {
    id?: true
    name?: true
    author?: true
    description?: true
    updateTime?: true
    createTime?: true
  }

  export type WordListMaxAggregateInputType = {
    id?: true
    name?: true
    author?: true
    description?: true
    updateTime?: true
    createTime?: true
  }

  export type WordListCountAggregateInputType = {
    id?: true
    name?: true
    author?: true
    description?: true
    updateTime?: true
    createTime?: true
    settings?: true
    _all?: true
  }

  export type WordListAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which WordList to aggregate.
     */
    where?: WordListWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WordLists to fetch.
     */
    orderBy?: WordListOrderByWithRelationInput | WordListOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: WordListWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WordLists from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WordLists.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned WordLists
    **/
    _count?: true | WordListCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: WordListAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: WordListSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: WordListMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: WordListMaxAggregateInputType
  }

  export type GetWordListAggregateType<T extends WordListAggregateArgs> = {
        [P in keyof T & keyof AggregateWordList]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateWordList[P]>
      : GetScalarType<T[P], AggregateWordList[P]>
  }




  export type WordListGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WordListWhereInput
    orderBy?: WordListOrderByWithAggregationInput | WordListOrderByWithAggregationInput[]
    by: WordListScalarFieldEnum[] | WordListScalarFieldEnum
    having?: WordListScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: WordListCountAggregateInputType | true
    _avg?: WordListAvgAggregateInputType
    _sum?: WordListSumAggregateInputType
    _min?: WordListMinAggregateInputType
    _max?: WordListMaxAggregateInputType
  }

  export type WordListGroupByOutputType = {
    id: string
    name: string
    author: string
    description: string | null
    updateTime: bigint
    createTime: bigint
    settings: JsonValue
    _count: WordListCountAggregateOutputType | null
    _avg: WordListAvgAggregateOutputType | null
    _sum: WordListSumAggregateOutputType | null
    _min: WordListMinAggregateOutputType | null
    _max: WordListMaxAggregateOutputType | null
  }

  type GetWordListGroupByPayload<T extends WordListGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<WordListGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof WordListGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], WordListGroupByOutputType[P]>
            : GetScalarType<T[P], WordListGroupByOutputType[P]>
        }
      >
    >


  export type WordListSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    author?: boolean
    description?: boolean
    updateTime?: boolean
    createTime?: boolean
    settings?: boolean
    words?: boolean | WordList$wordsArgs<ExtArgs>
    _count?: boolean | WordListCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["wordList"]>

  export type WordListSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    author?: boolean
    description?: boolean
    updateTime?: boolean
    createTime?: boolean
    settings?: boolean
  }, ExtArgs["result"]["wordList"]>

  export type WordListSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    author?: boolean
    description?: boolean
    updateTime?: boolean
    createTime?: boolean
    settings?: boolean
  }, ExtArgs["result"]["wordList"]>

  export type WordListSelectScalar = {
    id?: boolean
    name?: boolean
    author?: boolean
    description?: boolean
    updateTime?: boolean
    createTime?: boolean
    settings?: boolean
  }

  export type WordListOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "author" | "description" | "updateTime" | "createTime" | "settings", ExtArgs["result"]["wordList"]>
  export type WordListInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    words?: boolean | WordList$wordsArgs<ExtArgs>
    _count?: boolean | WordListCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type WordListIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type WordListIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $WordListPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "WordList"
    objects: {
      words: Prisma.$WordPairPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      author: string
      description: string | null
      updateTime: bigint
      createTime: bigint
      settings: Prisma.JsonValue
    }, ExtArgs["result"]["wordList"]>
    composites: {}
  }

  type WordListGetPayload<S extends boolean | null | undefined | WordListDefaultArgs> = $Result.GetResult<Prisma.$WordListPayload, S>

  type WordListCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<WordListFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: WordListCountAggregateInputType | true
    }

  export interface WordListDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['WordList'], meta: { name: 'WordList' } }
    /**
     * Find zero or one WordList that matches the filter.
     * @param {WordListFindUniqueArgs} args - Arguments to find a WordList
     * @example
     * // Get one WordList
     * const wordList = await prisma.wordList.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends WordListFindUniqueArgs>(args: SelectSubset<T, WordListFindUniqueArgs<ExtArgs>>): Prisma__WordListClient<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one WordList that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {WordListFindUniqueOrThrowArgs} args - Arguments to find a WordList
     * @example
     * // Get one WordList
     * const wordList = await prisma.wordList.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends WordListFindUniqueOrThrowArgs>(args: SelectSubset<T, WordListFindUniqueOrThrowArgs<ExtArgs>>): Prisma__WordListClient<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first WordList that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordListFindFirstArgs} args - Arguments to find a WordList
     * @example
     * // Get one WordList
     * const wordList = await prisma.wordList.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends WordListFindFirstArgs>(args?: SelectSubset<T, WordListFindFirstArgs<ExtArgs>>): Prisma__WordListClient<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first WordList that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordListFindFirstOrThrowArgs} args - Arguments to find a WordList
     * @example
     * // Get one WordList
     * const wordList = await prisma.wordList.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends WordListFindFirstOrThrowArgs>(args?: SelectSubset<T, WordListFindFirstOrThrowArgs<ExtArgs>>): Prisma__WordListClient<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more WordLists that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordListFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all WordLists
     * const wordLists = await prisma.wordList.findMany()
     * 
     * // Get first 10 WordLists
     * const wordLists = await prisma.wordList.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const wordListWithIdOnly = await prisma.wordList.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends WordListFindManyArgs>(args?: SelectSubset<T, WordListFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a WordList.
     * @param {WordListCreateArgs} args - Arguments to create a WordList.
     * @example
     * // Create one WordList
     * const WordList = await prisma.wordList.create({
     *   data: {
     *     // ... data to create a WordList
     *   }
     * })
     * 
     */
    create<T extends WordListCreateArgs>(args: SelectSubset<T, WordListCreateArgs<ExtArgs>>): Prisma__WordListClient<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many WordLists.
     * @param {WordListCreateManyArgs} args - Arguments to create many WordLists.
     * @example
     * // Create many WordLists
     * const wordList = await prisma.wordList.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends WordListCreateManyArgs>(args?: SelectSubset<T, WordListCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many WordLists and returns the data saved in the database.
     * @param {WordListCreateManyAndReturnArgs} args - Arguments to create many WordLists.
     * @example
     * // Create many WordLists
     * const wordList = await prisma.wordList.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many WordLists and only return the `id`
     * const wordListWithIdOnly = await prisma.wordList.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends WordListCreateManyAndReturnArgs>(args?: SelectSubset<T, WordListCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a WordList.
     * @param {WordListDeleteArgs} args - Arguments to delete one WordList.
     * @example
     * // Delete one WordList
     * const WordList = await prisma.wordList.delete({
     *   where: {
     *     // ... filter to delete one WordList
     *   }
     * })
     * 
     */
    delete<T extends WordListDeleteArgs>(args: SelectSubset<T, WordListDeleteArgs<ExtArgs>>): Prisma__WordListClient<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one WordList.
     * @param {WordListUpdateArgs} args - Arguments to update one WordList.
     * @example
     * // Update one WordList
     * const wordList = await prisma.wordList.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends WordListUpdateArgs>(args: SelectSubset<T, WordListUpdateArgs<ExtArgs>>): Prisma__WordListClient<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more WordLists.
     * @param {WordListDeleteManyArgs} args - Arguments to filter WordLists to delete.
     * @example
     * // Delete a few WordLists
     * const { count } = await prisma.wordList.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends WordListDeleteManyArgs>(args?: SelectSubset<T, WordListDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WordLists.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordListUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many WordLists
     * const wordList = await prisma.wordList.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends WordListUpdateManyArgs>(args: SelectSubset<T, WordListUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WordLists and returns the data updated in the database.
     * @param {WordListUpdateManyAndReturnArgs} args - Arguments to update many WordLists.
     * @example
     * // Update many WordLists
     * const wordList = await prisma.wordList.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more WordLists and only return the `id`
     * const wordListWithIdOnly = await prisma.wordList.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends WordListUpdateManyAndReturnArgs>(args: SelectSubset<T, WordListUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one WordList.
     * @param {WordListUpsertArgs} args - Arguments to update or create a WordList.
     * @example
     * // Update or create a WordList
     * const wordList = await prisma.wordList.upsert({
     *   create: {
     *     // ... data to create a WordList
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the WordList we want to update
     *   }
     * })
     */
    upsert<T extends WordListUpsertArgs>(args: SelectSubset<T, WordListUpsertArgs<ExtArgs>>): Prisma__WordListClient<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of WordLists.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordListCountArgs} args - Arguments to filter WordLists to count.
     * @example
     * // Count the number of WordLists
     * const count = await prisma.wordList.count({
     *   where: {
     *     // ... the filter for the WordLists we want to count
     *   }
     * })
    **/
    count<T extends WordListCountArgs>(
      args?: Subset<T, WordListCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], WordListCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a WordList.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordListAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WordListAggregateArgs>(args: Subset<T, WordListAggregateArgs>): Prisma.PrismaPromise<GetWordListAggregateType<T>>

    /**
     * Group by WordList.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordListGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends WordListGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: WordListGroupByArgs['orderBy'] }
        : { orderBy?: WordListGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, WordListGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWordListGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the WordList model
   */
  readonly fields: WordListFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for WordList.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__WordListClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    words<T extends WordList$wordsArgs<ExtArgs> = {}>(args?: Subset<T, WordList$wordsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the WordList model
   */
  interface WordListFieldRefs {
    readonly id: FieldRef<"WordList", 'String'>
    readonly name: FieldRef<"WordList", 'String'>
    readonly author: FieldRef<"WordList", 'String'>
    readonly description: FieldRef<"WordList", 'String'>
    readonly updateTime: FieldRef<"WordList", 'BigInt'>
    readonly createTime: FieldRef<"WordList", 'BigInt'>
    readonly settings: FieldRef<"WordList", 'Json'>
  }
    

  // Custom InputTypes
  /**
   * WordList findUnique
   */
  export type WordListFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordListInclude<ExtArgs> | null
    /**
     * Filter, which WordList to fetch.
     */
    where: WordListWhereUniqueInput
  }

  /**
   * WordList findUniqueOrThrow
   */
  export type WordListFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordListInclude<ExtArgs> | null
    /**
     * Filter, which WordList to fetch.
     */
    where: WordListWhereUniqueInput
  }

  /**
   * WordList findFirst
   */
  export type WordListFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordListInclude<ExtArgs> | null
    /**
     * Filter, which WordList to fetch.
     */
    where?: WordListWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WordLists to fetch.
     */
    orderBy?: WordListOrderByWithRelationInput | WordListOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WordLists.
     */
    cursor?: WordListWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WordLists from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WordLists.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WordLists.
     */
    distinct?: WordListScalarFieldEnum | WordListScalarFieldEnum[]
  }

  /**
   * WordList findFirstOrThrow
   */
  export type WordListFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordListInclude<ExtArgs> | null
    /**
     * Filter, which WordList to fetch.
     */
    where?: WordListWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WordLists to fetch.
     */
    orderBy?: WordListOrderByWithRelationInput | WordListOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WordLists.
     */
    cursor?: WordListWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WordLists from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WordLists.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WordLists.
     */
    distinct?: WordListScalarFieldEnum | WordListScalarFieldEnum[]
  }

  /**
   * WordList findMany
   */
  export type WordListFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordListInclude<ExtArgs> | null
    /**
     * Filter, which WordLists to fetch.
     */
    where?: WordListWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WordLists to fetch.
     */
    orderBy?: WordListOrderByWithRelationInput | WordListOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing WordLists.
     */
    cursor?: WordListWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WordLists from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WordLists.
     */
    skip?: number
    distinct?: WordListScalarFieldEnum | WordListScalarFieldEnum[]
  }

  /**
   * WordList create
   */
  export type WordListCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordListInclude<ExtArgs> | null
    /**
     * The data needed to create a WordList.
     */
    data: XOR<WordListCreateInput, WordListUncheckedCreateInput>
  }

  /**
   * WordList createMany
   */
  export type WordListCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many WordLists.
     */
    data: WordListCreateManyInput | WordListCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * WordList createManyAndReturn
   */
  export type WordListCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * The data used to create many WordLists.
     */
    data: WordListCreateManyInput | WordListCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * WordList update
   */
  export type WordListUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordListInclude<ExtArgs> | null
    /**
     * The data needed to update a WordList.
     */
    data: XOR<WordListUpdateInput, WordListUncheckedUpdateInput>
    /**
     * Choose, which WordList to update.
     */
    where: WordListWhereUniqueInput
  }

  /**
   * WordList updateMany
   */
  export type WordListUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update WordLists.
     */
    data: XOR<WordListUpdateManyMutationInput, WordListUncheckedUpdateManyInput>
    /**
     * Filter which WordLists to update
     */
    where?: WordListWhereInput
    /**
     * Limit how many WordLists to update.
     */
    limit?: number
  }

  /**
   * WordList updateManyAndReturn
   */
  export type WordListUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * The data used to update WordLists.
     */
    data: XOR<WordListUpdateManyMutationInput, WordListUncheckedUpdateManyInput>
    /**
     * Filter which WordLists to update
     */
    where?: WordListWhereInput
    /**
     * Limit how many WordLists to update.
     */
    limit?: number
  }

  /**
   * WordList upsert
   */
  export type WordListUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordListInclude<ExtArgs> | null
    /**
     * The filter to search for the WordList to update in case it exists.
     */
    where: WordListWhereUniqueInput
    /**
     * In case the WordList found by the `where` argument doesn't exist, create a new WordList with this data.
     */
    create: XOR<WordListCreateInput, WordListUncheckedCreateInput>
    /**
     * In case the WordList was found with the provided `where` argument, update it with this data.
     */
    update: XOR<WordListUpdateInput, WordListUncheckedUpdateInput>
  }

  /**
   * WordList delete
   */
  export type WordListDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordListInclude<ExtArgs> | null
    /**
     * Filter which WordList to delete.
     */
    where: WordListWhereUniqueInput
  }

  /**
   * WordList deleteMany
   */
  export type WordListDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which WordLists to delete
     */
    where?: WordListWhereInput
    /**
     * Limit how many WordLists to delete.
     */
    limit?: number
  }

  /**
   * WordList.words
   */
  export type WordList$wordsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
    where?: WordPairWhereInput
    orderBy?: WordPairOrderByWithRelationInput | WordPairOrderByWithRelationInput[]
    cursor?: WordPairWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WordPairScalarFieldEnum | WordPairScalarFieldEnum[]
  }

  /**
   * WordList without action
   */
  export type WordListDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordList
     */
    select?: WordListSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordList
     */
    omit?: WordListOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordListInclude<ExtArgs> | null
  }


  /**
   * Model WordPair
   */

  export type AggregateWordPair = {
    _count: WordPairCountAggregateOutputType | null
    _min: WordPairMinAggregateOutputType | null
    _max: WordPairMaxAggregateOutputType | null
  }

  export type WordPairMinAggregateOutputType = {
    id: string | null
    word1: string | null
    word2: string | null
    progress: string | null
    wordListId: string | null
  }

  export type WordPairMaxAggregateOutputType = {
    id: string | null
    word1: string | null
    word2: string | null
    progress: string | null
    wordListId: string | null
  }

  export type WordPairCountAggregateOutputType = {
    id: number
    word1: number
    word2: number
    progress: number
    wordListId: number
    _all: number
  }


  export type WordPairMinAggregateInputType = {
    id?: true
    word1?: true
    word2?: true
    progress?: true
    wordListId?: true
  }

  export type WordPairMaxAggregateInputType = {
    id?: true
    word1?: true
    word2?: true
    progress?: true
    wordListId?: true
  }

  export type WordPairCountAggregateInputType = {
    id?: true
    word1?: true
    word2?: true
    progress?: true
    wordListId?: true
    _all?: true
  }

  export type WordPairAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which WordPair to aggregate.
     */
    where?: WordPairWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WordPairs to fetch.
     */
    orderBy?: WordPairOrderByWithRelationInput | WordPairOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: WordPairWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WordPairs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WordPairs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned WordPairs
    **/
    _count?: true | WordPairCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: WordPairMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: WordPairMaxAggregateInputType
  }

  export type GetWordPairAggregateType<T extends WordPairAggregateArgs> = {
        [P in keyof T & keyof AggregateWordPair]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateWordPair[P]>
      : GetScalarType<T[P], AggregateWordPair[P]>
  }




  export type WordPairGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WordPairWhereInput
    orderBy?: WordPairOrderByWithAggregationInput | WordPairOrderByWithAggregationInput[]
    by: WordPairScalarFieldEnum[] | WordPairScalarFieldEnum
    having?: WordPairScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: WordPairCountAggregateInputType | true
    _min?: WordPairMinAggregateInputType
    _max?: WordPairMaxAggregateInputType
  }

  export type WordPairGroupByOutputType = {
    id: string
    word1: string
    word2: string
    progress: string
    wordListId: string
    _count: WordPairCountAggregateOutputType | null
    _min: WordPairMinAggregateOutputType | null
    _max: WordPairMaxAggregateOutputType | null
  }

  type GetWordPairGroupByPayload<T extends WordPairGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<WordPairGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof WordPairGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], WordPairGroupByOutputType[P]>
            : GetScalarType<T[P], WordPairGroupByOutputType[P]>
        }
      >
    >


  export type WordPairSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    word1?: boolean
    word2?: boolean
    progress?: boolean
    wordListId?: boolean
    wordList?: boolean | WordListDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["wordPair"]>

  export type WordPairSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    word1?: boolean
    word2?: boolean
    progress?: boolean
    wordListId?: boolean
    wordList?: boolean | WordListDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["wordPair"]>

  export type WordPairSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    word1?: boolean
    word2?: boolean
    progress?: boolean
    wordListId?: boolean
    wordList?: boolean | WordListDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["wordPair"]>

  export type WordPairSelectScalar = {
    id?: boolean
    word1?: boolean
    word2?: boolean
    progress?: boolean
    wordListId?: boolean
  }

  export type WordPairOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "word1" | "word2" | "progress" | "wordListId", ExtArgs["result"]["wordPair"]>
  export type WordPairInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    wordList?: boolean | WordListDefaultArgs<ExtArgs>
  }
  export type WordPairIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    wordList?: boolean | WordListDefaultArgs<ExtArgs>
  }
  export type WordPairIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    wordList?: boolean | WordListDefaultArgs<ExtArgs>
  }

  export type $WordPairPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "WordPair"
    objects: {
      wordList: Prisma.$WordListPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      word1: string
      word2: string
      progress: string
      wordListId: string
    }, ExtArgs["result"]["wordPair"]>
    composites: {}
  }

  type WordPairGetPayload<S extends boolean | null | undefined | WordPairDefaultArgs> = $Result.GetResult<Prisma.$WordPairPayload, S>

  type WordPairCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<WordPairFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: WordPairCountAggregateInputType | true
    }

  export interface WordPairDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['WordPair'], meta: { name: 'WordPair' } }
    /**
     * Find zero or one WordPair that matches the filter.
     * @param {WordPairFindUniqueArgs} args - Arguments to find a WordPair
     * @example
     * // Get one WordPair
     * const wordPair = await prisma.wordPair.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends WordPairFindUniqueArgs>(args: SelectSubset<T, WordPairFindUniqueArgs<ExtArgs>>): Prisma__WordPairClient<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one WordPair that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {WordPairFindUniqueOrThrowArgs} args - Arguments to find a WordPair
     * @example
     * // Get one WordPair
     * const wordPair = await prisma.wordPair.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends WordPairFindUniqueOrThrowArgs>(args: SelectSubset<T, WordPairFindUniqueOrThrowArgs<ExtArgs>>): Prisma__WordPairClient<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first WordPair that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordPairFindFirstArgs} args - Arguments to find a WordPair
     * @example
     * // Get one WordPair
     * const wordPair = await prisma.wordPair.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends WordPairFindFirstArgs>(args?: SelectSubset<T, WordPairFindFirstArgs<ExtArgs>>): Prisma__WordPairClient<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first WordPair that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordPairFindFirstOrThrowArgs} args - Arguments to find a WordPair
     * @example
     * // Get one WordPair
     * const wordPair = await prisma.wordPair.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends WordPairFindFirstOrThrowArgs>(args?: SelectSubset<T, WordPairFindFirstOrThrowArgs<ExtArgs>>): Prisma__WordPairClient<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more WordPairs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordPairFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all WordPairs
     * const wordPairs = await prisma.wordPair.findMany()
     * 
     * // Get first 10 WordPairs
     * const wordPairs = await prisma.wordPair.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const wordPairWithIdOnly = await prisma.wordPair.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends WordPairFindManyArgs>(args?: SelectSubset<T, WordPairFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a WordPair.
     * @param {WordPairCreateArgs} args - Arguments to create a WordPair.
     * @example
     * // Create one WordPair
     * const WordPair = await prisma.wordPair.create({
     *   data: {
     *     // ... data to create a WordPair
     *   }
     * })
     * 
     */
    create<T extends WordPairCreateArgs>(args: SelectSubset<T, WordPairCreateArgs<ExtArgs>>): Prisma__WordPairClient<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many WordPairs.
     * @param {WordPairCreateManyArgs} args - Arguments to create many WordPairs.
     * @example
     * // Create many WordPairs
     * const wordPair = await prisma.wordPair.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends WordPairCreateManyArgs>(args?: SelectSubset<T, WordPairCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many WordPairs and returns the data saved in the database.
     * @param {WordPairCreateManyAndReturnArgs} args - Arguments to create many WordPairs.
     * @example
     * // Create many WordPairs
     * const wordPair = await prisma.wordPair.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many WordPairs and only return the `id`
     * const wordPairWithIdOnly = await prisma.wordPair.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends WordPairCreateManyAndReturnArgs>(args?: SelectSubset<T, WordPairCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a WordPair.
     * @param {WordPairDeleteArgs} args - Arguments to delete one WordPair.
     * @example
     * // Delete one WordPair
     * const WordPair = await prisma.wordPair.delete({
     *   where: {
     *     // ... filter to delete one WordPair
     *   }
     * })
     * 
     */
    delete<T extends WordPairDeleteArgs>(args: SelectSubset<T, WordPairDeleteArgs<ExtArgs>>): Prisma__WordPairClient<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one WordPair.
     * @param {WordPairUpdateArgs} args - Arguments to update one WordPair.
     * @example
     * // Update one WordPair
     * const wordPair = await prisma.wordPair.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends WordPairUpdateArgs>(args: SelectSubset<T, WordPairUpdateArgs<ExtArgs>>): Prisma__WordPairClient<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more WordPairs.
     * @param {WordPairDeleteManyArgs} args - Arguments to filter WordPairs to delete.
     * @example
     * // Delete a few WordPairs
     * const { count } = await prisma.wordPair.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends WordPairDeleteManyArgs>(args?: SelectSubset<T, WordPairDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WordPairs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordPairUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many WordPairs
     * const wordPair = await prisma.wordPair.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends WordPairUpdateManyArgs>(args: SelectSubset<T, WordPairUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WordPairs and returns the data updated in the database.
     * @param {WordPairUpdateManyAndReturnArgs} args - Arguments to update many WordPairs.
     * @example
     * // Update many WordPairs
     * const wordPair = await prisma.wordPair.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more WordPairs and only return the `id`
     * const wordPairWithIdOnly = await prisma.wordPair.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends WordPairUpdateManyAndReturnArgs>(args: SelectSubset<T, WordPairUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one WordPair.
     * @param {WordPairUpsertArgs} args - Arguments to update or create a WordPair.
     * @example
     * // Update or create a WordPair
     * const wordPair = await prisma.wordPair.upsert({
     *   create: {
     *     // ... data to create a WordPair
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the WordPair we want to update
     *   }
     * })
     */
    upsert<T extends WordPairUpsertArgs>(args: SelectSubset<T, WordPairUpsertArgs<ExtArgs>>): Prisma__WordPairClient<$Result.GetResult<Prisma.$WordPairPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of WordPairs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordPairCountArgs} args - Arguments to filter WordPairs to count.
     * @example
     * // Count the number of WordPairs
     * const count = await prisma.wordPair.count({
     *   where: {
     *     // ... the filter for the WordPairs we want to count
     *   }
     * })
    **/
    count<T extends WordPairCountArgs>(
      args?: Subset<T, WordPairCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], WordPairCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a WordPair.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordPairAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WordPairAggregateArgs>(args: Subset<T, WordPairAggregateArgs>): Prisma.PrismaPromise<GetWordPairAggregateType<T>>

    /**
     * Group by WordPair.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WordPairGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends WordPairGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: WordPairGroupByArgs['orderBy'] }
        : { orderBy?: WordPairGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, WordPairGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWordPairGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the WordPair model
   */
  readonly fields: WordPairFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for WordPair.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__WordPairClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    wordList<T extends WordListDefaultArgs<ExtArgs> = {}>(args?: Subset<T, WordListDefaultArgs<ExtArgs>>): Prisma__WordListClient<$Result.GetResult<Prisma.$WordListPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the WordPair model
   */
  interface WordPairFieldRefs {
    readonly id: FieldRef<"WordPair", 'String'>
    readonly word1: FieldRef<"WordPair", 'String'>
    readonly word2: FieldRef<"WordPair", 'String'>
    readonly progress: FieldRef<"WordPair", 'String'>
    readonly wordListId: FieldRef<"WordPair", 'String'>
  }
    

  // Custom InputTypes
  /**
   * WordPair findUnique
   */
  export type WordPairFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
    /**
     * Filter, which WordPair to fetch.
     */
    where: WordPairWhereUniqueInput
  }

  /**
   * WordPair findUniqueOrThrow
   */
  export type WordPairFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
    /**
     * Filter, which WordPair to fetch.
     */
    where: WordPairWhereUniqueInput
  }

  /**
   * WordPair findFirst
   */
  export type WordPairFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
    /**
     * Filter, which WordPair to fetch.
     */
    where?: WordPairWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WordPairs to fetch.
     */
    orderBy?: WordPairOrderByWithRelationInput | WordPairOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WordPairs.
     */
    cursor?: WordPairWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WordPairs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WordPairs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WordPairs.
     */
    distinct?: WordPairScalarFieldEnum | WordPairScalarFieldEnum[]
  }

  /**
   * WordPair findFirstOrThrow
   */
  export type WordPairFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
    /**
     * Filter, which WordPair to fetch.
     */
    where?: WordPairWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WordPairs to fetch.
     */
    orderBy?: WordPairOrderByWithRelationInput | WordPairOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WordPairs.
     */
    cursor?: WordPairWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WordPairs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WordPairs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WordPairs.
     */
    distinct?: WordPairScalarFieldEnum | WordPairScalarFieldEnum[]
  }

  /**
   * WordPair findMany
   */
  export type WordPairFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
    /**
     * Filter, which WordPairs to fetch.
     */
    where?: WordPairWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WordPairs to fetch.
     */
    orderBy?: WordPairOrderByWithRelationInput | WordPairOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing WordPairs.
     */
    cursor?: WordPairWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WordPairs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WordPairs.
     */
    skip?: number
    distinct?: WordPairScalarFieldEnum | WordPairScalarFieldEnum[]
  }

  /**
   * WordPair create
   */
  export type WordPairCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
    /**
     * The data needed to create a WordPair.
     */
    data: XOR<WordPairCreateInput, WordPairUncheckedCreateInput>
  }

  /**
   * WordPair createMany
   */
  export type WordPairCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many WordPairs.
     */
    data: WordPairCreateManyInput | WordPairCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * WordPair createManyAndReturn
   */
  export type WordPairCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * The data used to create many WordPairs.
     */
    data: WordPairCreateManyInput | WordPairCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * WordPair update
   */
  export type WordPairUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
    /**
     * The data needed to update a WordPair.
     */
    data: XOR<WordPairUpdateInput, WordPairUncheckedUpdateInput>
    /**
     * Choose, which WordPair to update.
     */
    where: WordPairWhereUniqueInput
  }

  /**
   * WordPair updateMany
   */
  export type WordPairUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update WordPairs.
     */
    data: XOR<WordPairUpdateManyMutationInput, WordPairUncheckedUpdateManyInput>
    /**
     * Filter which WordPairs to update
     */
    where?: WordPairWhereInput
    /**
     * Limit how many WordPairs to update.
     */
    limit?: number
  }

  /**
   * WordPair updateManyAndReturn
   */
  export type WordPairUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * The data used to update WordPairs.
     */
    data: XOR<WordPairUpdateManyMutationInput, WordPairUncheckedUpdateManyInput>
    /**
     * Filter which WordPairs to update
     */
    where?: WordPairWhereInput
    /**
     * Limit how many WordPairs to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * WordPair upsert
   */
  export type WordPairUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
    /**
     * The filter to search for the WordPair to update in case it exists.
     */
    where: WordPairWhereUniqueInput
    /**
     * In case the WordPair found by the `where` argument doesn't exist, create a new WordPair with this data.
     */
    create: XOR<WordPairCreateInput, WordPairUncheckedCreateInput>
    /**
     * In case the WordPair was found with the provided `where` argument, update it with this data.
     */
    update: XOR<WordPairUpdateInput, WordPairUncheckedUpdateInput>
  }

  /**
   * WordPair delete
   */
  export type WordPairDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
    /**
     * Filter which WordPair to delete.
     */
    where: WordPairWhereUniqueInput
  }

  /**
   * WordPair deleteMany
   */
  export type WordPairDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which WordPairs to delete
     */
    where?: WordPairWhereInput
    /**
     * Limit how many WordPairs to delete.
     */
    limit?: number
  }

  /**
   * WordPair without action
   */
  export type WordPairDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WordPair
     */
    select?: WordPairSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WordPair
     */
    omit?: WordPairOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WordPairInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const WordListScalarFieldEnum: {
    id: 'id',
    name: 'name',
    author: 'author',
    description: 'description',
    updateTime: 'updateTime',
    createTime: 'createTime',
    settings: 'settings'
  };

  export type WordListScalarFieldEnum = (typeof WordListScalarFieldEnum)[keyof typeof WordListScalarFieldEnum]


  export const WordPairScalarFieldEnum: {
    id: 'id',
    word1: 'word1',
    word2: 'word2',
    progress: 'progress',
    wordListId: 'wordListId'
  };

  export type WordPairScalarFieldEnum = (typeof WordPairScalarFieldEnum)[keyof typeof WordPairScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const JsonNullValueInput: {
    JsonNull: typeof JsonNull
  };

  export type JsonNullValueInput = (typeof JsonNullValueInput)[keyof typeof JsonNullValueInput]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'BigInt'
   */
  export type BigIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BigInt'>
    


  /**
   * Reference to a field of type 'BigInt[]'
   */
  export type ListBigIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BigInt[]'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'QueryMode'
   */
  export type EnumQueryModeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'QueryMode'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type WordListWhereInput = {
    AND?: WordListWhereInput | WordListWhereInput[]
    OR?: WordListWhereInput[]
    NOT?: WordListWhereInput | WordListWhereInput[]
    id?: StringFilter<"WordList"> | string
    name?: StringFilter<"WordList"> | string
    author?: StringFilter<"WordList"> | string
    description?: StringNullableFilter<"WordList"> | string | null
    updateTime?: BigIntFilter<"WordList"> | bigint | number
    createTime?: BigIntFilter<"WordList"> | bigint | number
    settings?: JsonFilter<"WordList">
    words?: WordPairListRelationFilter
  }

  export type WordListOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    author?: SortOrder
    description?: SortOrderInput | SortOrder
    updateTime?: SortOrder
    createTime?: SortOrder
    settings?: SortOrder
    words?: WordPairOrderByRelationAggregateInput
  }

  export type WordListWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: WordListWhereInput | WordListWhereInput[]
    OR?: WordListWhereInput[]
    NOT?: WordListWhereInput | WordListWhereInput[]
    name?: StringFilter<"WordList"> | string
    author?: StringFilter<"WordList"> | string
    description?: StringNullableFilter<"WordList"> | string | null
    updateTime?: BigIntFilter<"WordList"> | bigint | number
    createTime?: BigIntFilter<"WordList"> | bigint | number
    settings?: JsonFilter<"WordList">
    words?: WordPairListRelationFilter
  }, "id">

  export type WordListOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    author?: SortOrder
    description?: SortOrderInput | SortOrder
    updateTime?: SortOrder
    createTime?: SortOrder
    settings?: SortOrder
    _count?: WordListCountOrderByAggregateInput
    _avg?: WordListAvgOrderByAggregateInput
    _max?: WordListMaxOrderByAggregateInput
    _min?: WordListMinOrderByAggregateInput
    _sum?: WordListSumOrderByAggregateInput
  }

  export type WordListScalarWhereWithAggregatesInput = {
    AND?: WordListScalarWhereWithAggregatesInput | WordListScalarWhereWithAggregatesInput[]
    OR?: WordListScalarWhereWithAggregatesInput[]
    NOT?: WordListScalarWhereWithAggregatesInput | WordListScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"WordList"> | string
    name?: StringWithAggregatesFilter<"WordList"> | string
    author?: StringWithAggregatesFilter<"WordList"> | string
    description?: StringNullableWithAggregatesFilter<"WordList"> | string | null
    updateTime?: BigIntWithAggregatesFilter<"WordList"> | bigint | number
    createTime?: BigIntWithAggregatesFilter<"WordList"> | bigint | number
    settings?: JsonWithAggregatesFilter<"WordList">
  }

  export type WordPairWhereInput = {
    AND?: WordPairWhereInput | WordPairWhereInput[]
    OR?: WordPairWhereInput[]
    NOT?: WordPairWhereInput | WordPairWhereInput[]
    id?: StringFilter<"WordPair"> | string
    word1?: StringFilter<"WordPair"> | string
    word2?: StringFilter<"WordPair"> | string
    progress?: StringFilter<"WordPair"> | string
    wordListId?: StringFilter<"WordPair"> | string
    wordList?: XOR<WordListScalarRelationFilter, WordListWhereInput>
  }

  export type WordPairOrderByWithRelationInput = {
    id?: SortOrder
    word1?: SortOrder
    word2?: SortOrder
    progress?: SortOrder
    wordListId?: SortOrder
    wordList?: WordListOrderByWithRelationInput
  }

  export type WordPairWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: WordPairWhereInput | WordPairWhereInput[]
    OR?: WordPairWhereInput[]
    NOT?: WordPairWhereInput | WordPairWhereInput[]
    word1?: StringFilter<"WordPair"> | string
    word2?: StringFilter<"WordPair"> | string
    progress?: StringFilter<"WordPair"> | string
    wordListId?: StringFilter<"WordPair"> | string
    wordList?: XOR<WordListScalarRelationFilter, WordListWhereInput>
  }, "id">

  export type WordPairOrderByWithAggregationInput = {
    id?: SortOrder
    word1?: SortOrder
    word2?: SortOrder
    progress?: SortOrder
    wordListId?: SortOrder
    _count?: WordPairCountOrderByAggregateInput
    _max?: WordPairMaxOrderByAggregateInput
    _min?: WordPairMinOrderByAggregateInput
  }

  export type WordPairScalarWhereWithAggregatesInput = {
    AND?: WordPairScalarWhereWithAggregatesInput | WordPairScalarWhereWithAggregatesInput[]
    OR?: WordPairScalarWhereWithAggregatesInput[]
    NOT?: WordPairScalarWhereWithAggregatesInput | WordPairScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"WordPair"> | string
    word1?: StringWithAggregatesFilter<"WordPair"> | string
    word2?: StringWithAggregatesFilter<"WordPair"> | string
    progress?: StringWithAggregatesFilter<"WordPair"> | string
    wordListId?: StringWithAggregatesFilter<"WordPair"> | string
  }

  export type WordListCreateInput = {
    id?: string
    name: string
    author: string
    description?: string | null
    updateTime: bigint | number
    createTime: bigint | number
    settings: JsonNullValueInput | InputJsonValue
    words?: WordPairCreateNestedManyWithoutWordListInput
  }

  export type WordListUncheckedCreateInput = {
    id?: string
    name: string
    author: string
    description?: string | null
    updateTime: bigint | number
    createTime: bigint | number
    settings: JsonNullValueInput | InputJsonValue
    words?: WordPairUncheckedCreateNestedManyWithoutWordListInput
  }

  export type WordListUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    author?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    updateTime?: BigIntFieldUpdateOperationsInput | bigint | number
    createTime?: BigIntFieldUpdateOperationsInput | bigint | number
    settings?: JsonNullValueInput | InputJsonValue
    words?: WordPairUpdateManyWithoutWordListNestedInput
  }

  export type WordListUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    author?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    updateTime?: BigIntFieldUpdateOperationsInput | bigint | number
    createTime?: BigIntFieldUpdateOperationsInput | bigint | number
    settings?: JsonNullValueInput | InputJsonValue
    words?: WordPairUncheckedUpdateManyWithoutWordListNestedInput
  }

  export type WordListCreateManyInput = {
    id?: string
    name: string
    author: string
    description?: string | null
    updateTime: bigint | number
    createTime: bigint | number
    settings: JsonNullValueInput | InputJsonValue
  }

  export type WordListUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    author?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    updateTime?: BigIntFieldUpdateOperationsInput | bigint | number
    createTime?: BigIntFieldUpdateOperationsInput | bigint | number
    settings?: JsonNullValueInput | InputJsonValue
  }

  export type WordListUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    author?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    updateTime?: BigIntFieldUpdateOperationsInput | bigint | number
    createTime?: BigIntFieldUpdateOperationsInput | bigint | number
    settings?: JsonNullValueInput | InputJsonValue
  }

  export type WordPairCreateInput = {
    id?: string
    word1: string
    word2: string
    progress: string
    wordList: WordListCreateNestedOneWithoutWordsInput
  }

  export type WordPairUncheckedCreateInput = {
    id?: string
    word1: string
    word2: string
    progress: string
    wordListId: string
  }

  export type WordPairUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    word1?: StringFieldUpdateOperationsInput | string
    word2?: StringFieldUpdateOperationsInput | string
    progress?: StringFieldUpdateOperationsInput | string
    wordList?: WordListUpdateOneRequiredWithoutWordsNestedInput
  }

  export type WordPairUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    word1?: StringFieldUpdateOperationsInput | string
    word2?: StringFieldUpdateOperationsInput | string
    progress?: StringFieldUpdateOperationsInput | string
    wordListId?: StringFieldUpdateOperationsInput | string
  }

  export type WordPairCreateManyInput = {
    id?: string
    word1: string
    word2: string
    progress: string
    wordListId: string
  }

  export type WordPairUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    word1?: StringFieldUpdateOperationsInput | string
    word2?: StringFieldUpdateOperationsInput | string
    progress?: StringFieldUpdateOperationsInput | string
  }

  export type WordPairUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    word1?: StringFieldUpdateOperationsInput | string
    word2?: StringFieldUpdateOperationsInput | string
    progress?: StringFieldUpdateOperationsInput | string
    wordListId?: StringFieldUpdateOperationsInput | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type BigIntFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntFilter<$PrismaModel> | bigint | number
  }
  export type JsonFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonFilterBase<$PrismaModel>>, 'path'>>

  export type JsonFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type WordPairListRelationFilter = {
    every?: WordPairWhereInput
    some?: WordPairWhereInput
    none?: WordPairWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type WordPairOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type WordListCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    author?: SortOrder
    description?: SortOrder
    updateTime?: SortOrder
    createTime?: SortOrder
    settings?: SortOrder
  }

  export type WordListAvgOrderByAggregateInput = {
    updateTime?: SortOrder
    createTime?: SortOrder
  }

  export type WordListMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    author?: SortOrder
    description?: SortOrder
    updateTime?: SortOrder
    createTime?: SortOrder
  }

  export type WordListMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    author?: SortOrder
    description?: SortOrder
    updateTime?: SortOrder
    createTime?: SortOrder
  }

  export type WordListSumOrderByAggregateInput = {
    updateTime?: SortOrder
    createTime?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type BigIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntWithAggregatesFilter<$PrismaModel> | bigint | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedBigIntFilter<$PrismaModel>
    _min?: NestedBigIntFilter<$PrismaModel>
    _max?: NestedBigIntFilter<$PrismaModel>
  }
  export type JsonWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedJsonFilter<$PrismaModel>
    _max?: NestedJsonFilter<$PrismaModel>
  }

  export type WordListScalarRelationFilter = {
    is?: WordListWhereInput
    isNot?: WordListWhereInput
  }

  export type WordPairCountOrderByAggregateInput = {
    id?: SortOrder
    word1?: SortOrder
    word2?: SortOrder
    progress?: SortOrder
    wordListId?: SortOrder
  }

  export type WordPairMaxOrderByAggregateInput = {
    id?: SortOrder
    word1?: SortOrder
    word2?: SortOrder
    progress?: SortOrder
    wordListId?: SortOrder
  }

  export type WordPairMinOrderByAggregateInput = {
    id?: SortOrder
    word1?: SortOrder
    word2?: SortOrder
    progress?: SortOrder
    wordListId?: SortOrder
  }

  export type WordPairCreateNestedManyWithoutWordListInput = {
    create?: XOR<WordPairCreateWithoutWordListInput, WordPairUncheckedCreateWithoutWordListInput> | WordPairCreateWithoutWordListInput[] | WordPairUncheckedCreateWithoutWordListInput[]
    connectOrCreate?: WordPairCreateOrConnectWithoutWordListInput | WordPairCreateOrConnectWithoutWordListInput[]
    createMany?: WordPairCreateManyWordListInputEnvelope
    connect?: WordPairWhereUniqueInput | WordPairWhereUniqueInput[]
  }

  export type WordPairUncheckedCreateNestedManyWithoutWordListInput = {
    create?: XOR<WordPairCreateWithoutWordListInput, WordPairUncheckedCreateWithoutWordListInput> | WordPairCreateWithoutWordListInput[] | WordPairUncheckedCreateWithoutWordListInput[]
    connectOrCreate?: WordPairCreateOrConnectWithoutWordListInput | WordPairCreateOrConnectWithoutWordListInput[]
    createMany?: WordPairCreateManyWordListInputEnvelope
    connect?: WordPairWhereUniqueInput | WordPairWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type BigIntFieldUpdateOperationsInput = {
    set?: bigint | number
    increment?: bigint | number
    decrement?: bigint | number
    multiply?: bigint | number
    divide?: bigint | number
  }

  export type WordPairUpdateManyWithoutWordListNestedInput = {
    create?: XOR<WordPairCreateWithoutWordListInput, WordPairUncheckedCreateWithoutWordListInput> | WordPairCreateWithoutWordListInput[] | WordPairUncheckedCreateWithoutWordListInput[]
    connectOrCreate?: WordPairCreateOrConnectWithoutWordListInput | WordPairCreateOrConnectWithoutWordListInput[]
    upsert?: WordPairUpsertWithWhereUniqueWithoutWordListInput | WordPairUpsertWithWhereUniqueWithoutWordListInput[]
    createMany?: WordPairCreateManyWordListInputEnvelope
    set?: WordPairWhereUniqueInput | WordPairWhereUniqueInput[]
    disconnect?: WordPairWhereUniqueInput | WordPairWhereUniqueInput[]
    delete?: WordPairWhereUniqueInput | WordPairWhereUniqueInput[]
    connect?: WordPairWhereUniqueInput | WordPairWhereUniqueInput[]
    update?: WordPairUpdateWithWhereUniqueWithoutWordListInput | WordPairUpdateWithWhereUniqueWithoutWordListInput[]
    updateMany?: WordPairUpdateManyWithWhereWithoutWordListInput | WordPairUpdateManyWithWhereWithoutWordListInput[]
    deleteMany?: WordPairScalarWhereInput | WordPairScalarWhereInput[]
  }

  export type WordPairUncheckedUpdateManyWithoutWordListNestedInput = {
    create?: XOR<WordPairCreateWithoutWordListInput, WordPairUncheckedCreateWithoutWordListInput> | WordPairCreateWithoutWordListInput[] | WordPairUncheckedCreateWithoutWordListInput[]
    connectOrCreate?: WordPairCreateOrConnectWithoutWordListInput | WordPairCreateOrConnectWithoutWordListInput[]
    upsert?: WordPairUpsertWithWhereUniqueWithoutWordListInput | WordPairUpsertWithWhereUniqueWithoutWordListInput[]
    createMany?: WordPairCreateManyWordListInputEnvelope
    set?: WordPairWhereUniqueInput | WordPairWhereUniqueInput[]
    disconnect?: WordPairWhereUniqueInput | WordPairWhereUniqueInput[]
    delete?: WordPairWhereUniqueInput | WordPairWhereUniqueInput[]
    connect?: WordPairWhereUniqueInput | WordPairWhereUniqueInput[]
    update?: WordPairUpdateWithWhereUniqueWithoutWordListInput | WordPairUpdateWithWhereUniqueWithoutWordListInput[]
    updateMany?: WordPairUpdateManyWithWhereWithoutWordListInput | WordPairUpdateManyWithWhereWithoutWordListInput[]
    deleteMany?: WordPairScalarWhereInput | WordPairScalarWhereInput[]
  }

  export type WordListCreateNestedOneWithoutWordsInput = {
    create?: XOR<WordListCreateWithoutWordsInput, WordListUncheckedCreateWithoutWordsInput>
    connectOrCreate?: WordListCreateOrConnectWithoutWordsInput
    connect?: WordListWhereUniqueInput
  }

  export type WordListUpdateOneRequiredWithoutWordsNestedInput = {
    create?: XOR<WordListCreateWithoutWordsInput, WordListUncheckedCreateWithoutWordsInput>
    connectOrCreate?: WordListCreateOrConnectWithoutWordsInput
    upsert?: WordListUpsertWithoutWordsInput
    connect?: WordListWhereUniqueInput
    update?: XOR<XOR<WordListUpdateToOneWithWhereWithoutWordsInput, WordListUpdateWithoutWordsInput>, WordListUncheckedUpdateWithoutWordsInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedBigIntFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntFilter<$PrismaModel> | bigint | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedBigIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntWithAggregatesFilter<$PrismaModel> | bigint | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedBigIntFilter<$PrismaModel>
    _min?: NestedBigIntFilter<$PrismaModel>
    _max?: NestedBigIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }
  export type NestedJsonFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type WordPairCreateWithoutWordListInput = {
    id?: string
    word1: string
    word2: string
    progress: string
  }

  export type WordPairUncheckedCreateWithoutWordListInput = {
    id?: string
    word1: string
    word2: string
    progress: string
  }

  export type WordPairCreateOrConnectWithoutWordListInput = {
    where: WordPairWhereUniqueInput
    create: XOR<WordPairCreateWithoutWordListInput, WordPairUncheckedCreateWithoutWordListInput>
  }

  export type WordPairCreateManyWordListInputEnvelope = {
    data: WordPairCreateManyWordListInput | WordPairCreateManyWordListInput[]
    skipDuplicates?: boolean
  }

  export type WordPairUpsertWithWhereUniqueWithoutWordListInput = {
    where: WordPairWhereUniqueInput
    update: XOR<WordPairUpdateWithoutWordListInput, WordPairUncheckedUpdateWithoutWordListInput>
    create: XOR<WordPairCreateWithoutWordListInput, WordPairUncheckedCreateWithoutWordListInput>
  }

  export type WordPairUpdateWithWhereUniqueWithoutWordListInput = {
    where: WordPairWhereUniqueInput
    data: XOR<WordPairUpdateWithoutWordListInput, WordPairUncheckedUpdateWithoutWordListInput>
  }

  export type WordPairUpdateManyWithWhereWithoutWordListInput = {
    where: WordPairScalarWhereInput
    data: XOR<WordPairUpdateManyMutationInput, WordPairUncheckedUpdateManyWithoutWordListInput>
  }

  export type WordPairScalarWhereInput = {
    AND?: WordPairScalarWhereInput | WordPairScalarWhereInput[]
    OR?: WordPairScalarWhereInput[]
    NOT?: WordPairScalarWhereInput | WordPairScalarWhereInput[]
    id?: StringFilter<"WordPair"> | string
    word1?: StringFilter<"WordPair"> | string
    word2?: StringFilter<"WordPair"> | string
    progress?: StringFilter<"WordPair"> | string
    wordListId?: StringFilter<"WordPair"> | string
  }

  export type WordListCreateWithoutWordsInput = {
    id?: string
    name: string
    author: string
    description?: string | null
    updateTime: bigint | number
    createTime: bigint | number
    settings: JsonNullValueInput | InputJsonValue
  }

  export type WordListUncheckedCreateWithoutWordsInput = {
    id?: string
    name: string
    author: string
    description?: string | null
    updateTime: bigint | number
    createTime: bigint | number
    settings: JsonNullValueInput | InputJsonValue
  }

  export type WordListCreateOrConnectWithoutWordsInput = {
    where: WordListWhereUniqueInput
    create: XOR<WordListCreateWithoutWordsInput, WordListUncheckedCreateWithoutWordsInput>
  }

  export type WordListUpsertWithoutWordsInput = {
    update: XOR<WordListUpdateWithoutWordsInput, WordListUncheckedUpdateWithoutWordsInput>
    create: XOR<WordListCreateWithoutWordsInput, WordListUncheckedCreateWithoutWordsInput>
    where?: WordListWhereInput
  }

  export type WordListUpdateToOneWithWhereWithoutWordsInput = {
    where?: WordListWhereInput
    data: XOR<WordListUpdateWithoutWordsInput, WordListUncheckedUpdateWithoutWordsInput>
  }

  export type WordListUpdateWithoutWordsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    author?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    updateTime?: BigIntFieldUpdateOperationsInput | bigint | number
    createTime?: BigIntFieldUpdateOperationsInput | bigint | number
    settings?: JsonNullValueInput | InputJsonValue
  }

  export type WordListUncheckedUpdateWithoutWordsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    author?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    updateTime?: BigIntFieldUpdateOperationsInput | bigint | number
    createTime?: BigIntFieldUpdateOperationsInput | bigint | number
    settings?: JsonNullValueInput | InputJsonValue
  }

  export type WordPairCreateManyWordListInput = {
    id?: string
    word1: string
    word2: string
    progress: string
  }

  export type WordPairUpdateWithoutWordListInput = {
    id?: StringFieldUpdateOperationsInput | string
    word1?: StringFieldUpdateOperationsInput | string
    word2?: StringFieldUpdateOperationsInput | string
    progress?: StringFieldUpdateOperationsInput | string
  }

  export type WordPairUncheckedUpdateWithoutWordListInput = {
    id?: StringFieldUpdateOperationsInput | string
    word1?: StringFieldUpdateOperationsInput | string
    word2?: StringFieldUpdateOperationsInput | string
    progress?: StringFieldUpdateOperationsInput | string
  }

  export type WordPairUncheckedUpdateManyWithoutWordListInput = {
    id?: StringFieldUpdateOperationsInput | string
    word1?: StringFieldUpdateOperationsInput | string
    word2?: StringFieldUpdateOperationsInput | string
    progress?: StringFieldUpdateOperationsInput | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}