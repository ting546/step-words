"use client";

const Notify = ({deleted,  successed}) => {
  return (
    <></>
    // <div className=" absolute none items-center justify-center top-0 left-0 w-full h-full z-50 gray  bg-gray-800/80">
    //   <LoaderCircle  size={40} className="text-blue-800 animate-spin" />
    // </div>
  );
};
export default Notify;
